

LLM_NAME = "ollama/llama3.1"
BASE_URL="http://localhost:11434"
TEMPERATURE=0